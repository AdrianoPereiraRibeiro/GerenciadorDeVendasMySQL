/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gerenciaprodutosfinalversion.Repositorios;

import com.mycompany.gerenciaprodutosfinalversion.Objetos.Venda;
import com.mycompany.gerenciaprodutosfinalversion.Objetos.Produto;
import java.sql.*;

import java.sql.*;
import java.util.ArrayList;

// Classe RepositorioVenda com suporte a ID e operações completas
public class RepositorioVenda {

    private final String jdbcUrl = "jdbc:mysql://localhost:3306/localhostbanco?useSSL=false&serverTimezone=UTC";
    private final String username = "root";
    private final String password = "root";

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
        }
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    public void inserirVenda(Venda venda) {
        String insertVenda = "INSERT INTO Venda (valorTotal) VALUES (?)";
        String insertVendaProduto = "INSERT INTO VendaProduto (idVenda, codigoProduto) VALUES (?, ?)";

        try (Connection conn = conectar()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtVenda = conn.prepareStatement(insertVenda, Statement.RETURN_GENERATED_KEYS)) {
                stmtVenda.setDouble(1, venda.getValorTotalVenda());
                stmtVenda.executeUpdate();

                try (ResultSet rs = stmtVenda.getGeneratedKeys()) {
                    if (rs.next()) {
                        int idVenda = rs.getInt(1);
                        venda.setId(idVenda);
                    }
                }

                try (PreparedStatement stmtVP = conn.prepareStatement(insertVendaProduto)) {
                    for (Produto p : venda.getProdutos()) {
                        stmtVP.setInt(1, venda.getId());
                        stmtVP.setInt(2, p.getCodigo());
                        stmtVP.addBatch();
                    }
                    stmtVP.executeBatch();
                }

                conn.commit();
                System.out.println("Venda salva com ID: " + venda.getId());

            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Erro durante a inserção da venda: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.err.println("Erro ao conectar ou inserir venda: " + e.getMessage());
        }
    }

    public ArrayList<Venda> listarVendas() {
        ArrayList<Venda> vendas = new ArrayList<>();
        String sqlVenda = "SELECT * FROM Venda";
        String sqlProdutos = "SELECT p.* FROM Produto p JOIN VendaProduto vp ON p.codigo = vp.codigoProduto WHERE vp.idVenda = ?";

        try (Connection conn = conectar(); PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda)) {
            ResultSet rsVenda = stmtVenda.executeQuery();

            while (rsVenda.next()) {
                int idVenda = rsVenda.getInt("id");
                double valor = rsVenda.getDouble("valorTotal");

                Venda v = new Venda(valor);
                v.setId(idVenda);

                try (PreparedStatement stmtProdutos = conn.prepareStatement(sqlProdutos)) {
                    stmtProdutos.setInt(1, idVenda);
                    ResultSet rsProdutos = stmtProdutos.executeQuery();

                    while (rsProdutos.next()) {
                        Produto p = new Produto();
                        p.setCodigo(rsProdutos.getInt("codigo"));
                        p.setNome(rsProdutos.getString("nome"));
                        p.setPreco(rsProdutos.getDouble("preco"));
                        v.getProdutos().add(p);
                    }
                }

                vendas.add(v);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar vendas: " + e.getMessage());
        }

        return vendas;
    }

    public Venda buscarVendaPorCodigo(int idVenda) {
        String sql = "SELECT * FROM Venda WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idVenda);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Venda v = new Venda(rs.getDouble("valorTotal"));
                v.setId(idVenda);

                String sqlProdutos = "SELECT p.* FROM Produto p JOIN VendaProduto vp ON p.codigo = vp.codigoProduto WHERE vp.idVenda = ?";
                try (PreparedStatement stmtProd = conn.prepareStatement(sqlProdutos)) {
                    stmtProd.setInt(1, idVenda);
                    ResultSet rsProd = stmtProd.executeQuery();
                    while (rsProd.next()) {
                        Produto p = new Produto();
                        p.setCodigo(rsProd.getInt("codigo"));
                        p.setNome(rsProd.getString("nome"));
                        p.setPreco(rsProd.getDouble("preco"));
                        v.getProdutos().add(p);
                    }
                }

                return v;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar venda: " + e.getMessage());
        }

        return null;
    }

    public boolean excluirVenda(int idVenda) {
        String deleteVendaProduto = "DELETE FROM VendaProduto WHERE idVenda = ?";
        String deleteVenda = "DELETE FROM Venda WHERE id = ?";
        try (Connection conn = conectar()) {
            conn.setAutoCommit(false);
            try (
                PreparedStatement stmtVP = conn.prepareStatement(deleteVendaProduto);
                PreparedStatement stmtVenda = conn.prepareStatement(deleteVenda)
            ) {
                stmtVP.setInt(1, idVenda);
                stmtVP.executeUpdate();

                stmtVenda.setInt(1, idVenda);
                int linhas = stmtVenda.executeUpdate();

                conn.commit();
                return linhas > 0;
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Erro ao excluir venda: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Erro de conexão: " + e.getMessage());
        }
        return false;
    }
}