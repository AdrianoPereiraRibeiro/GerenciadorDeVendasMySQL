/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gerenciaprodutosfinalversion.Repositorios;

import com.mycompany.gerenciaprodutosfinalversion.Objetos.Produto;
import java.sql.*;
import java.util.ArrayList;

import java.sql.*;
import java.util.ArrayList;

public class RepositorioProduto {

    private final String jdbcUrl = "jdbc:mysql://localhost:3306/localhostbanco?useSSL=false&serverTimezone=UTC";
    private final String username = "root";
    private final String password = "root";

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
        }
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    public void inserirProduto(Produto produto) {
        String sql = "INSERT INTO Produto (codigo, nome, preco) VALUES (?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, produto.getCodigo());
            stmt.setString(2, produto.getNome());
            stmt.setDouble(3, produto.getPreco());
            stmt.executeUpdate();
            System.out.println("Produto inserido com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao inserir produto: " + e.getMessage());
        }
    }

    public ArrayList<Produto> listarProdutos() {
        ArrayList<Produto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Produto";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Produto p = new Produto();
                p.setCodigo(rs.getInt("codigo"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                lista.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar produtos: " + e.getMessage());
        }
        return lista;
    }
    public boolean excluirProduto(int codigo) {
    String sql = "DELETE FROM Produto WHERE codigo = ?";
    try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, codigo);
        int linhasAfetadas = stmt.executeUpdate();
        if (linhasAfetadas > 0) {
            System.out.println("Produto excluído com sucesso!");
            return true;
        } else {
            System.out.println("Nenhum produto encontrado com o código informado.");
        }
    } catch (SQLException e) {
        System.err.println("Erro ao excluir produto: " + e.getMessage());
    }
    return false;
}

    public Produto buscarProdutoPorCodigo(int codigo) {
    String sql = "SELECT * FROM Produto WHERE codigo = ?";
    try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, codigo);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                Produto produto = new Produto();
                produto.setCodigo(rs.getInt("codigo"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                return produto;
            }
        }
    } catch (SQLException e) {
        System.err.println("Erro ao buscar produto: " + e.getMessage());
    }
    return null; 
}

}
