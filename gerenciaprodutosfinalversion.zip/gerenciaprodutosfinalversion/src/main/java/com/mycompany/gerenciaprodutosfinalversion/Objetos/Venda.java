/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gerenciaprodutosfinalversion.Objetos;

import java.util.ArrayList;
import java.util.Scanner;

public class Venda implements VendaInterface {
    
    private int id;
    public ArrayList<Produto> produtos = new ArrayList<>();
    public double valorTotalVenda;

    public Venda() {}

    public Venda(double valorTotalVenda) {
        this.valorTotalVenda = valorTotalVenda;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public double getValorTotalVenda() {
        return valorTotalVenda;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    @Override
    public void calcularValorDaVenda() {
        double soma = 0;
        for (Produto produto : produtos) {
            soma += produto.getPreco();
        }
        valorTotalVenda = soma;
    }

    @Override
    public void adicionarProdutoNaVenda(ArrayList<Produto> produtosCadastrados) {
        Scanner scanner = new Scanner(System.in);
        for (Produto p : produtosCadastrados) {
            System.out.println(p.getCodigo() + " " + p.getNome());
        }
        System.out.println("Digite o codigo do produto para ser adicionado na compra:");
        int cod = Integer.parseInt(scanner.nextLine());
        for (Produto p : produtosCadastrados) {
            if (cod == p.getCodigo()) {
                produtos.add(p);
            }
        }
    }

    @Override
    public Venda cadastrarVenda(ArrayList<Produto> produtosCadastrados) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite quantos produtos voce deseja adicionar na venda:");
        int qtd = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < qtd; i++) {
            adicionarProdutoNaVenda(produtosCadastrados);
        }
        calcularValorDaVenda();
        Venda venda = new Venda(valorTotalVenda);
        venda.produtos = produtos;
        return venda;
    }

    @Override
    public String toString() {
        return "Venda{" + "produtos=" + produtos.size() + ", valorTotalVenda=" + valorTotalVenda + '}';
    }
}